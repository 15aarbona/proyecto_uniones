"""Esquema canonico de resultados CODAME (`Tabla_MOMENT_M1`, 63 columnas).

Los resultados del servidor son SIEMPRE estas columnas, independientemente del modelo.
Cada modelo las produce con su `to_codame()`; el servidor solo reordena y, como red de
seguridad, rellena con `CODAME_DEFAULTS` las que falten (nunca falla por culpa del
modelo). Referencia: `doc/codame/mapeo_columnas_codame.md`.
"""

# Orden de las columnas de Tabla_MOMENT_M1.
CODAME_COLUMNS = [
    "Unicode",
    "Standards",
    "BEAM",
    "COLUMN",
    "MzEd_Porcen",
    "FyEd_Porcen",
    "FxEd_Porcen",
    "Pr_Porcen",
    "Traccion",
    "MzEd_PanelZone",
    "Vgra",
    "Havg",
    "BoltName_ep",
    "p2_ep",
    "ThicknessName_t_webstiff",
    "Bws",
    "Lws",
    "b_ep",
    "Lp",
    "ThicknessName_t_ep",
    "Lh",
    "AnguloCantonera",
    "dev",
    "p12_Outer",
    "pfo",
    "pfi",
    "pb",
    "p3",
    "p4",
    "p5",
    "p6",
    "p7",
    "p8",
    "p9",
    "p10",
    "p11",
    "p12",
    "ThicknessName_t_compstiff",
    "ThicknessName_t_BeamHcompstiff",
    "ThicknessName_t_tenstiff",
    "wf",
    "ww",
    "w3",
    "w4",
    "wh",
    "FactorCantoCantonera",
    "ntensionrows",
    "fy",
    "fu",
    "fyp",
    "fup",
    "E",
    "BoltGrade",
    "BoltThreads",
    "Electrode",
    "yieldmethod",
    "WeldFactor",
    "BoltsInTensionFactor",
    "SisUniBoltSI",
    "SisUniPlateSI",
    "Source",
    "Designation",
    "Estado_IA",
]

# Valor simbolico por defecto (red de seguridad / columnas que el cliente no rellena).
CODAME_DEFAULTS = {c: 0.0 for c in CODAME_COLUMNS}
CODAME_DEFAULTS.update({
    "Unicode": "",
    "Standards": "",
    "BEAM": "",
    "COLUMN": "",
    "Traccion": "",
    "BoltName_ep": "",
    "ThicknessName_t_webstiff": "0mm",
    "ThicknessName_t_ep": "0mm",
    "ThicknessName_t_compstiff": "0mm",
    "ThicknessName_t_BeamHcompstiff": "0mm",
    "ThicknessName_t_tenstiff": "0mm",
    "ntensionrows": 2,
    "BoltGrade": "",
    "BoltThreads": True,
    "Electrode": "",
    "yieldmethod": True,
    "WeldFactor": 1,
    "BoltsInTensionFactor": 2,
    "SisUniBoltSI": "",
    "SisUniPlateSI": "",
    "Source": "",
    "Designation": "",
    "Estado_IA": "",
})


def fill_missing(row: dict) -> dict:
    """Rellena con los defaults las columnas que falten, en el orden canonico."""
    return {c: row.get(c, CODAME_DEFAULTS[c]) for c in CODAME_COLUMNS}
